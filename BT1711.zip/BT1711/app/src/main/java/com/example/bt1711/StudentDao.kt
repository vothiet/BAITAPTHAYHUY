
package com.example.bt1711

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentDao {

    // Lấy danh sách sinh viên, mới nhất lên đầu
    @Query("SELECT * FROM students_table ORDER BY id DESC")
    fun getAllStudents(): Flow<List<Student>>

    // Thêm sinh viên
    @Insert
    suspend fun insert(student: Student)

    // Cập nhật thông tin sinh viên
    @Update
    suspend fun update(student: Student)

    // Xóa sinh viên
    @Delete
    suspend fun delete(student: Student)
}
