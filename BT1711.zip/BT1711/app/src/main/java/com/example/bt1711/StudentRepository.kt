
package com.example.bt1711

import kotlinx.coroutines.flow.Flow

class StudentRepository(
    private val studentDao: StudentDao
) {

    // Lấy toàn bộ danh sách sinh viên
    val allStudents: Flow<List<Student>> =
        studentDao.getAllStudents()

    // Thêm sinh viên
    suspend fun insert(student: Student) {
        studentDao.insert(student)
    }

    // Cập nhật thông tin sinh viên
    suspend fun update(student: Student) {
        studentDao.update(student)
    }

    // Xóa sinh viên
    suspend fun delete(student: Student) {
        studentDao.delete(student)
    }
}
