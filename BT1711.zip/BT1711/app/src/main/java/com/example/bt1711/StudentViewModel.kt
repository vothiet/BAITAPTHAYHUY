
package com.example.bt1711

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StudentViewModel(
    private val repository: StudentRepository
) : ViewModel() {

    // Lấy danh sách sinh viên từ Repository
    val allStudents: LiveData<List<Student>> =
        repository.allStudents.asLiveData()

    // Thêm sinh viên
    fun insert(student: Student) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insert(student)
        }
    }

    // Cập nhật thông tin sinh viên
    fun update(student: Student) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.update(student)
        }
    }

    // Xóa sinh viên
    fun delete(student: Student) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.delete(student)
        }
    }
}
