package com.example.btdtdd229

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class EditActivity : AppCompatActivity() {

    private lateinit var edtName: EditText
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_edit)

        edtName = findViewById(R.id.edtName)
        btnSave = findViewById(R.id.btnSave)

        // Nhận tên từ MainActivity
        val currentName =
            intent.getStringExtra("KEY_NAME") ?: ""

        // Hiển thị tên hiện tại
        edtName.setText(currentName)

        // Nút Lưu & Quay lại
        btnSave.setOnClickListener {

            val newName = edtName.text.toString()

            val resultIntent = Intent()

            resultIntent.putExtra(
                "KEY_NAME",
                newName
            )

            // Gửi kết quả về MainActivity
            setResult(
                Activity.RESULT_OK,
                resultIntent
            )

            // Đóng EditActivity
            finish()
        }
    }
}