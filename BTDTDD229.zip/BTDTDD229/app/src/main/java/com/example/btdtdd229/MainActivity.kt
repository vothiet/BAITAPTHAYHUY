package com.example.btdtdd229

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvProfileName: TextView
    private lateinit var btnEdit: Button

    private val editLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->

        if (result.resultCode == Activity.RESULT_OK) {

            val newName =
                result.data?.getStringExtra("KEY_NAME") ?: ""

            tvProfileName.text = "Họ tên: $newName"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        tvProfileName = findViewById(R.id.tvProfileName)
        btnEdit = findViewById(R.id.btnEdit)
        btnEdit.setOnClickListener {

            val intent = Intent(
                this,
                EditActivity::class.java
            )

            intent.putExtra(
                "KEY_NAME",
                tvProfileName.text.toString()
            )

            editLauncher.launch(intent)
        }
    }
}